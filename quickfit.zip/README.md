Submitted by: Aditya Kalkar (directory id: akalkar)
Group Members: Aditya Kalkar (akalkar), Sai Chanda (schanda), Thomas Lazzarini (tomlazz)
App Description: A fitness web app that lets users generate random workouts, rate them, and save their favorites to a personal history
YouTube Video Link: [https://youtu.be/lEetMgvEJLc]
APIs: [https://www.api-ninjas.com/api/exercises]
Contact Email:  akalkar@terpmail.umd.edu
Deployed App Link: [https://quickfit.onrender.com]